<?php
		
	

	add_filter(
	    'yatco_connect_shortcode_yacht_quick_search_template', 
	    function($template) {

	        $template=__DIR__.'/yatco-connect/quick-search.php';

	        return $template;

	    }
	);

	add_filter(
	    'yatco_connect_shortcode_yacht_search_template', 
	    function($template) {

	        $template=__DIR__.'/templates/search-form.php';

	        return $template;

	    }
	);

	add_filter(
		'yatco_connect_shortcode_yacht_results_template', 
		function($template) {

			$template=__DIR__.'/templates/yacht-results.php';

			return $template;

		}
	);

	add_filter('single_template', function($single_template) {

		global $post, $wp_query;

		if (is_singular('yatco_yachts')) {

			$vessel = $post->boss_data;
			
			// ACTIVE
			if ($vessel->MiscInfo->Status == 1 || $vessel->MiscInfo->Status == 4) {				
				$single_template = __DIR__.'/templates/single-yacht.php';
			}
			// Sold or otherwise
			else { //if ($vessel->MiscInfo->Status == 99) {
				$wp_query->is_404 = TRUE;
				//$single_template = __DIR__.'/templates/single-sold-yacht.php';
			}

		}

		return $single_template;

	}, 15, 1);