<?php
	add_action('init', function() {

	    add_rewrite_rule('/yacht-for-sale/([^/]+?)-(\d+)/?$', 'index.php?post_type=yatco_yachts&yacht_name=$matches[1]&yacht_id=$matches[2]', 'top');

	});

	add_filter('wp_yatco_yacht_url', function($url, $vessel) {

	    if (isset($vessel->BoatName)) {

	        $vessel->VesselName = $vessel->BoatName;

	    }

	    $_url=get_site_url().'/yacht-for-sale/'.trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($vessel->VesselName)),'-').'-'. $vessel->MLSID .'/';

	    return $_url;

	}, 10, 2);
		
	add_filter('wpseo_title', function($title) {
		global $wp_query;

		if (is_singular('yatco_yachts')) {
			$yacht = $wp_query->queried_object->boss_data;

			$title = $yacht->BasicInfo->BoatName." Yacht for Sale | ".  $yacht->Dimensions->LOAFeet ." ". $yacht->BasicInfo->Builder ." ". $yacht->BasicInfo->YearBuilt ." | Your Superyacht";
		}

		return $title;
	}, 20, 1);
		
	add_filter('wpseo_metadesc', function($metadesc) {
	    //Andiamo Yacht for sale is a 2009 BENETTI 194' 7" Motor Yacht in Miami, Florida, United States. Find the boat that best meets your needs today.
	    global $wp_query;

	    $v_id = 'yacht_id';

	    if (isset($wp_query->query_vars[$v_id])) {
	        $yacht = $wp_query->queried_object->boss_data;

	        $metadesc = $yacht->BasicInfo->BoatName.' Yacht for sale is a '. $yacht->Dimensions->LOAFeet .' '. $yacht->BasicInfo->Builder .' '.  $yacht->BasicInfo->YearBuilt .', one of the finest yachts in the worldwide fleet to accommodate your family and friends.';
	    } 

	    return $metadesc;
	}, 20, 1);
		