<div class="yt-col-12 yt-col-md-6 yt-col-lg-6 col-yacht">
  <div class="card forsale forsaleGallery">
     	<div class="VesselTagContainer">
       	<?php 
       		switch ($vessel->tags[0]) {
       			case 1:
                echo '<div class="VesselTag BankOwned">
                    Bank Owned
                </div>';
                break;

            case 2:
                echo '<div class="VesselTag Trade">
                    Trade
                </div>';
                break;

            case 3:
                echo '<div class="VesselTag MustGo">
                    Must Go
                </div>';
                break;

            case 4:
						    echo '<div class="VesselTag FeaturedForsale">
                    Featured
                </div>';

                break;

            default:
                /*echo '<div class="VesselTag FeaturedForsale">
                    Featured
                </div>';*/
               	break;

       		}
          
          $onclick = esc_attr(sprintf(
            ' openContactModal("%s", "%s", "%s", "%s"); ',
            $vessel->VesselID,
            $vessel->BrokerList[0]->CompanyID,
            addslashes($vessel->BrokerList[0]->CompanyName),
            addslashes($vessel->BrokerList[0]->BrokerName)
          ));
       	?>
    </div>

    <a href="<?= $vessel->a_url ?>">
      <div class="pic pic-wide ">
        <picture>
          <source media="(min-width: 650px)" srcset="<?= $vessel_medium_main_img ?>">
          <img src="<?= $vessel->MainPhotoUrl ?>" alt="<?= $vessel->VesselName ?> <?= $vessel->MLSID ?>" loading="lazy" >
        </picture>
        
        <div class="overlay"></div>
      </div>
    </a>                      

    <div class="below-picture">
      <a class="link-title" href="<?= $vessel->a_url ?>">
        <div class="card-title" style="">
          <?= $vessel->Year ?> 
          <?= $vessel->BuilderName ?>
          <?= $vessel->LoaFormat ?>
        </div>

      	<div class="card-title card-name greyfont">
          <?= $vessel->VesselName ?>
        </div>

        <div class="card-price ellipsis">
        	<?= $vessel->AskingPriceFormattedNoCurrency ?>
        </div>
      </a>

      <div class="btnRow" style="position: absolute; bottom: 5px; right: 10px;">
          <a onclick="<?= $onclick ?>">
          	Contact
          </a>
      </div>
    </div>
  </div>
</div>